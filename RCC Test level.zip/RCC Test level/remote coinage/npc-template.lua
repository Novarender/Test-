local npcSettings = {
	id=NPC_ID,
	width=32,
	height=32,
	gfxwidth=32,
	gfxheight=32,
	harmlessgrab=true,
}

-------

local npc = {}
local npcManager = require("npcManager")
local npcAI = require("npc/npc")

npcManager.setNpcSettings(npcSettings)
npcAI.registerID(NPC_ID)

return npc