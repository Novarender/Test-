local remoteCC = require("remoteCC")

local fx = {}
local myShader = Shader()
myShader:compileFromFile(nil, "flash.frag")

local duration = 34

function onDraw()
    for _,v in ipairs(NPC.get(241)) do
        if v.speedY > 4 then --lazy
            table.insert(fx, {timer = 0, w = {x=v.x, y=v.y, width=v.width, height=v.height}})
        end
    end
    for _,w in ipairs(NPC.get(138)) do
        if w.collidesBlockBottom then
            remoteCC.collect(w)
        end
    end

    for i = #fx, 1, -1 do
        local f = fx[i]
        local v = f.w

        Graphics.drawBox {
            x = v.x - 600,
            y = v.y - 600,
            width = 600*2 + v.width,
            height = 600*2 + v.height,
            
            sceneCoords = true,
            shader = myShader, uniforms = {time = f.timer/duration, r = seed},
        }
        if Defines.levelFreeze then
            f.timer = f.timer + 0.15
        else
            f.timer = f.timer + 0.8
        end
        if f.timer >= duration then
            table.remove(fx, i)
        end
    end
end